self.__precacheManifest = [
  {
    "revision": "5ae24a12f10baea945af",
    "url": "/vending/subvending/static/js/runtime~main.5ae24a12.js"
  },
  {
    "revision": "e2a18291c891b7840e8a",
    "url": "/vending/subvending/static/js/main.e2a18291.chunk.js"
  },
  {
    "revision": "50e6bb3cba37496b81b0",
    "url": "/vending/subvending/static/js/1.50e6bb3c.chunk.js"
  },
  {
    "revision": "e2a18291c891b7840e8a",
    "url": "/vending/subvending/static/css/main.107d13ce.chunk.css"
  },
  {
    "revision": "50e6bb3cba37496b81b0",
    "url": "/vending/subvending/static/css/1.93df11c1.chunk.css"
  },
  {
    "revision": "9801a43a793da379505541eed6fa7fb7",
    "url": "/vending/subvending/index.html"
  }
];