self.__precacheManifest = [
  {
    "revision": "5ae24a12f10baea945af",
    "url": "/vending/subvending/static/js/runtime~main.5ae24a12.js"
  },
  {
    "revision": "44214d38843a89a0e11d",
    "url": "/vending/subvending/static/js/main.44214d38.chunk.js"
  },
  {
    "revision": "50e6bb3cba37496b81b0",
    "url": "/vending/subvending/static/js/1.50e6bb3c.chunk.js"
  },
  {
    "revision": "44214d38843a89a0e11d",
    "url": "/vending/subvending/static/css/main.107d13ce.chunk.css"
  },
  {
    "revision": "50e6bb3cba37496b81b0",
    "url": "/vending/subvending/static/css/1.93df11c1.chunk.css"
  },
  {
    "revision": "7e62d3cae8b0671fb07690d6c93ddda5",
    "url": "/vending/subvending/index.html"
  }
];